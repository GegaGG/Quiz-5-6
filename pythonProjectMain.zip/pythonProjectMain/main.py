from flask import Flask, redirect, url_for, render_template, request, session
import requests
from bs4 import BeautifulSoup
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SECRET_KEY'] = 'quiz5_6'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///dogs_db.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class Dogs(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dog_breed = db.Column(db.String(45), nullable=False)
    dog_img = db.Column(db.String(150), nullable=False)
    dog_price = db.Column(db.String(30), nullable=False)

    def __str__(self):
        return f'Dog breed:{self.dog_breed} imgage link:{self.dog_img} price:{self.dog_price}'


db.create_all()


@app.route('/')
@app.route('/main')
@app.route('/home')
def Home():
    return render_template('HomePage.html')



@app.route('/search', methods=['GET', 'POST'])
def SearchB():
    if request.method == 'POST':
        search = request.form['search']
        page = 1
        dog_imgs = []
        dog_prices = []
        dog_breeds = []
        while page < 11:
            url = f'https://www.greenfieldpuppies.com/new-arrivals/page/' + str(page)
            req = requests.get(url)
            # print(req)
            soup = BeautifulSoup(req.text, 'html.parser')
            pets = soup.find('ul', class_='new-arivals-list puppy-list')
            # print(pets)
            dogs = pets.findAll('li', class_='col-1-4 puppy-box')
            # print(dogs)
            for dzaglebi in dogs:
                dog_breed = dzaglebi.find('span', class_="puppy-breed").text
                imgs = dzaglebi.find('img', class_='puppy-img lazy-load')
                dog_img = imgs.get('data-original')
                dog_price = dzaglebi.find('span', class_='puppy-price').text

                if search == dog_breed:
                    dog_breeds.append(dog_breed)
                    dog_imgs.append(dog_img)
                    dog_prices.append(dog_price)
                    t = Dogs(dog_breed=dog_breed, dog_img=dog_img, dog_price=dog_price)
                    db.session.add(t)
                    db.session.commit()
            page += 1
        return render_template('SearchResults.html', len=len(dog_breeds), dog_imgs=dog_imgs, dog_breeds=dog_breeds, dog_prices=dog_prices)
    return render_template('Search.html')


@app.route('/results')
def results():

    return render_template('SearchResults.html')


@app.route('/popular')
def Popular():
    return redirect('https://petkeen.com/most-popular-dog-breeds/')


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        session['my_user'] = username
        return redirect(url_for('SearchB'))
    return render_template('login.html')


@app.route('/about')
@app.route('/aboutus')
def about():
    return render_template('About.html')


if __name__ == '__main__':
    app.run(debug=True)